#!/usr/bin/env python3
"""
Luma Image Generation → OpenAI Chat Completions API adapter.

Flow:
  1. POST /api/vespa/realms/{realm_id}/actions  → submit generation task
  2. GET  /api/vespa/realms/{realm_id}/actions   → poll until action.state == "completed"
  3. GET  /api/vespa/realms/{realm_id}/artifacts/{output_id} → get artifact details (object_ref)
  4. GET  /api/vespa/realms/{realm_id}/signature → dynamically fetch CDN signing params
  5. Construct signed CDN URL using the signing params
  6. Return the URL in an OpenAI-compatible chat completion response.

Image references (img2img):
  When the user sends image_url content (base64 or URL), we:
  1. POST /api/vespa/realms/{realm_id}/artifacts → create artifact record, get presigned S3 URL
  2. PUT  image binary to the presigned S3 URL
  3. POST /api/vespa/realms/{realm_id}/artifacts/{id}/complete → notify upload complete
  4. Pass artifact ID in the "references" field of the generation request

Cookie auto-refresh:
  Every API response from Luma includes a Set-Cookie header with an updated wos-session.
  We capture this and update the in-memory session value for subsequent requests.

Streaming:
  When stream=true, sends SSE heartbeat (empty content) every 10s to keep connection alive,
  then sends the final image URL and [DONE].
"""

import base64
import io
import json
import logging
import os
import re
import struct
import string
import random
import time
import uuid
import asyncio
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import quote, urlencode

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
import uvicorn

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
load_dotenv()

REALM_ID = os.getenv("LUMA_REALM_ID", "")
ASPECT_RATIO = os.getenv("LUMA_ASPECT_RATIO", "")
POLL_INTERVAL = int(os.getenv("LUMA_POLL_INTERVAL", "3"))
MAX_POLLS = int(os.getenv("LUMA_MAX_POLLS", "60"))
PORT = int(os.getenv("PORT", "8188"))
HOST = os.getenv("HOST", "0.0.0.0")
HEARTBEAT_INTERVAL = int(os.getenv("HEARTBEAT_INTERVAL", "10"))

MODEL_BASE = "nano-banana-pro"

# Model name → (resolution, aspect_ratio) mapping
# Generated as cross-product of resolutions × aspect ratios
# Format: nano-banana-pro[-resolution][-aspect]
#   e.g. nano-banana-pro, nano-banana-pro-2k, nano-banana-pro-2k-16x9

RESOLUTIONS = [("", ""), ("1k", "1K"), ("2k", "2K"), ("4k", "4K")]
ASPECT_RATIOS = [
    ("", ""),
    ("16x9", "16:9"),
    ("1x1", "1:1"),
    ("9x16", "9:16"),
    ("4x3", "4:3"),
    ("3x4", "3:4"),
    ("21x9", "21:9"),
]

# Build the full model map: model_id → {"resolution": ..., "aspect_ratio": ...}
MODELS: dict[str, dict[str, str]] = {}
for res_suffix, res_value in RESOLUTIONS:
    for ar_suffix, ar_value in ASPECT_RATIOS:
        parts = [MODEL_BASE]
        if res_suffix:
            parts.append(res_suffix)
        if ar_suffix:
            parts.append(ar_suffix)
        model_id = "-".join(parts)
        MODELS[model_id] = {"resolution": res_value, "aspect_ratio": ar_value}

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0"
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("luma2api")


# ---------------------------------------------------------------------------
# Session state (mutable at runtime)
# ---------------------------------------------------------------------------

class SessionState:
    """Holds mutable session state that gets auto-refreshed."""

    def __init__(self):
        self.wos_session: str = os.getenv("LUMA_WOS_SESSION", "")
        self.user_logged_in: str = os.getenv("LUMA_USER_LOGGED_IN", "true")
        # Cached CDN signing params
        self._cdn_query_params: str = ""
        self._cdn_expires_at: Optional[datetime] = None
        self._cdn_base_url: str = "https://cdn.prod01.labs.lumalabs.ai"

    def update_cookie_from_response(self, response: httpx.Response) -> None:
        """
        Extract and update wos-session from Set-Cookie response headers.
        The server sends a new wos-session on every API response.
        """
        set_cookie_headers = response.headers.get_list("set-cookie")
        for sc in set_cookie_headers:
            if sc.startswith("wos-session="):
                value = sc.split(";")[0].split("=", 1)[1]
                if value and value != self.wos_session:
                    old_prefix = self.wos_session[:20] if self.wos_session else "(empty)"
                    self.wos_session = value
                    log.info(
                        "Cookie refreshed: wos-session %s... → %s...",
                        old_prefix, value[:20]
                    )
                break

    def cookie_str(self) -> str:
        return f"user-logged-in={self.user_logged_in}; wos-session={self.wos_session}"

    def is_signature_valid(self) -> bool:
        if not self._cdn_query_params or not self._cdn_expires_at:
            return False
        now = datetime.now(timezone.utc)
        margin = self._cdn_expires_at.timestamp() - 300
        return now.timestamp() < margin

    async def fetch_signature(self, client: httpx.AsyncClient) -> str:
        if self.is_signature_valid():
            return self._cdn_query_params

        sig_url = f"https://app.lumalabs.ai/api/vespa/realms/{REALM_ID}/signature"
        resp = await client.get(
            sig_url,
            headers=self._common_headers({"accept": "application/json"}),
        )
        self.update_cookie_from_response(resp)

        if resp.status_code != 200:
            raise RuntimeError(f"Failed to fetch signature: {resp.status_code} {resp.text[:200]}")

        data = resp.json()
        self._cdn_query_params = data.get("query_params", "")
        expires_str = data.get("expires_at", "")
        if expires_str:
            self._cdn_expires_at = datetime.fromisoformat(expires_str.replace("Z", "+00:00"))
        cdn_url = data.get("cdn_url", "")
        if cdn_url:
            self._cdn_base_url = cdn_url

        log.info("CDN signature fetched, expires_at=%s", expires_str)
        return self._cdn_query_params

    def build_signed_cdn_url(self, object_ref: str) -> str:
        base_url = f"{self._cdn_base_url}/{object_ref}"
        return f"{base_url}?{self._cdn_query_params}"

    def _common_headers(self, extra: Optional[dict] = None) -> dict:
        h = {
            "user-agent": USER_AGENT,
            "cookie": self.cookie_str(),
            "origin": "https://app.lumalabs.ai",
            "referer": f"https://app.lumalabs.ai/board/{REALM_ID}",
        }
        if extra:
            h.update(extra)
        return h


# Global session state
session = SessionState()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ID_CHARS = string.ascii_letters + string.digits

def _random_output_id(length: int = 8) -> str:
    return "".join(random.choices(_ID_CHARS, k=length))


# ---------------------------------------------------------------------------
# Image utilities (no Pillow dependency — parse headers manually)
# ---------------------------------------------------------------------------

def _detect_image_info(data: bytes) -> tuple[str, int, int]:
    """
    Detect image MIME type and dimensions from raw bytes.
    Returns (mime_type, width, height). Supports JPEG, PNG, GIF, WebP, BMP.
    """
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        # PNG: width and height at bytes 16-23 in IHDR chunk
        w, h = struct.unpack('>II', data[16:24])
        return "image/png", w, h
    elif data[:2] == b'\xff\xd8':
        # JPEG: scan for SOF0/SOF2 markers
        return _detect_jpeg_dimensions(data)
    elif data[:6] in (b'GIF87a', b'GIF89a'):
        w, h = struct.unpack('<HH', data[6:10])
        return "image/gif", w, h
    elif data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return _detect_webp_dimensions(data)
    elif data[:2] == b'BM':
        w, h = struct.unpack('<ii', data[18:26])
        return "image/bmp", abs(w), abs(h)
    # Fallback
    return "image/jpeg", 0, 0


def _detect_jpeg_dimensions(data: bytes) -> tuple[str, int, int]:
    """Parse JPEG SOF markers to extract dimensions."""
    i = 2
    while i < len(data) - 9:
        if data[i] != 0xFF:
            break
        marker = data[i + 1]
        if marker in (0xC0, 0xC1, 0xC2, 0xC3):
            h, w = struct.unpack('>HH', data[i + 5:i + 9])
            return "image/jpeg", w, h
        # Skip this segment
        seg_len = struct.unpack('>H', data[i + 2:i + 4])[0]
        i += 2 + seg_len
    return "image/jpeg", 0, 0


def _detect_webp_dimensions(data: bytes) -> tuple[str, int, int]:
    """Parse WebP to extract dimensions."""
    chunk_type = data[12:16]
    if chunk_type == b'VP8 ':
        # Lossy WebP
        w = struct.unpack('<H', data[26:28])[0] & 0x3FFF
        h = struct.unpack('<H', data[28:30])[0] & 0x3FFF
        return "image/webp", w, h
    elif chunk_type == b'VP8L':
        # Lossless WebP
        bits = struct.unpack('<I', data[21:25])[0]
        w = (bits & 0x3FFF) + 1
        h = ((bits >> 14) & 0x3FFF) + 1
        return "image/webp", w, h
    elif chunk_type == b'VP8X':
        # Extended WebP
        w = struct.unpack('<I', data[24:27] + b'\x00')[0] + 1
        h = struct.unpack('<I', data[27:30] + b'\x00')[0] + 1
        return "image/webp", w, h
    return "image/webp", 0, 0


_MIME_TO_EXT = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/bmp": "bmp",
}


async def _fetch_image_bytes(image_url: str, client: httpx.AsyncClient) -> bytes:
    """Download image from URL or decode base64 data URI."""
    if image_url.startswith("data:"):
        # data:image/jpeg;base64,/9j/4AAQ...
        _, encoded = image_url.split(",", 1)
        return base64.b64decode(encoded)
    else:
        resp = await client.get(image_url, follow_redirects=True)
        resp.raise_for_status()
        return resp.content


async def luma_upload_image(
    image_data: bytes,
    client: httpx.AsyncClient,
) -> str:
    """
    Upload an image to Luma and return the artifact ID for use as a reference.

    Matches the exact browser flow from packet capture:
      1. Detect image type and dimensions
      2. POST /api/vespa/realms/{realm_id}/artifacts → create artifact record with presigned_url
      3. PUT image binary to the presigned S3 URL
      4. POST /api/vespa/realms/{realm_id}/artifacts/{id}/complete → notify upload complete
      5. Return the artifact ID
    """
    mime_type, width, height = _detect_image_info(image_data)
    ext = _MIME_TO_EXT.get(mime_type, "jpg")
    artifact_id = _random_output_id()
    name = f"uploaded_{artifact_id}"

    log.info(
        "Uploading image: id=%s mime=%s %dx%d size=%d bytes",
        artifact_id, mime_type, width, height, len(image_data),
    )

    # ── Step 1: create artifact record ──
    create_url = f"https://app.lumalabs.ai/api/vespa/realms/{REALM_ID}/artifacts"
    body = {
        "type": mime_type,
        "id": artifact_id,
        "source": "upload",
        "name": name,
        "meta": {"width": width, "height": height},
    }
    resp = await client.post(
        create_url,
        json=body,
        headers=session._common_headers({
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "x-client-capabilities": "retry,upgrade_plan",
            "x-client-context": f"id={uuid.uuid4()},name=web,locale=zh-CN",
        }),
    )
    session.update_cookie_from_response(resp)

    if resp.status_code >= 400:
        raise RuntimeError(
            f"Failed to create artifact: {resp.status_code} {resp.text[:300]}"
        )

    artifact_data = resp.json()
    presigned_url = artifact_data.get("presigned_url", "")
    if not presigned_url:
        raise RuntimeError("No presigned_url returned when creating artifact")

    log.info("Artifact created: id=%s, presigned_url=%s...", artifact_id, presigned_url[:80])

    # ── Step 2: PUT image binary to S3 ──
    put_resp = await client.put(
        presigned_url,
        content=image_data,
        headers={"content-type": mime_type},
    )
    if put_resp.status_code >= 400:
        raise RuntimeError(
            f"Failed to upload image to S3: {put_resp.status_code} {put_resp.text[:200]}"
        )
    log.info("Image uploaded to S3: status=%s", put_resp.status_code)

    # ── Step 3: notify Luma that upload is complete ──
    complete_url = f"https://app.lumalabs.ai/api/vespa/realms/{REALM_ID}/artifacts/{artifact_id}/complete"
    complete_resp = await client.post(
        complete_url,
        json={},
        headers=session._common_headers({
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "x-client-capabilities": "retry,upgrade_plan",
            "x-client-context": f"id={uuid.uuid4()},name=web,locale=zh-CN",
        }),
    )
    session.update_cookie_from_response(complete_resp)
    if complete_resp.status_code >= 400:
        log.warning("Artifact complete notification failed: %s %s",
                     complete_resp.status_code, complete_resp.text[:200])
    else:
        log.info("Artifact upload complete notified: id=%s status=%s",
                 artifact_id, complete_resp.status_code)

    return artifact_id


def _extract_messages(messages: list) -> tuple[str, list[str]]:
    """
    Extract prompt text and image URLs from the last user message.
    Supports OpenAI multimodal content format:
      - content: "string"
      - content: [{"type": "text", "text": "..."}, {"type": "image_url", "image_url": {"url": "..."}}]

    Returns (prompt, image_urls).
    """
    prompt = ""
    image_urls: list[str] = []

    for msg in reversed(messages):
        if msg.get("role") != "user":
            continue
        content = msg.get("content", "")
        if isinstance(content, str):
            prompt = content
        elif isinstance(content, list):
            text_parts = []
            for part in content:
                if part.get("type") == "text":
                    text_parts.append(part.get("text", ""))
                elif part.get("type") == "image_url":
                    url_field = part.get("image_url", {})
                    if isinstance(url_field, str):
                        image_urls.append(url_field)
                    elif isinstance(url_field, dict):
                        image_urls.append(url_field.get("url", ""))
            prompt = " ".join(text_parts)
        break

    return prompt, image_urls


def _sse_chunk(completion_id: str, model: str, content: str = "",
               finish_reason: Optional[str] = None) -> str:
    """Build a single SSE data line in OpenAI chat.completion.chunk format."""
    delta = {}
    if content:
        delta["content"] = content
    if finish_reason is None and not content:
        # heartbeat: empty delta with role
        delta["role"] = "assistant"

    chunk = {
        "id": completion_id,
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": delta if finish_reason is None else {},
                "finish_reason": finish_reason,
            }
        ],
    }
    return f"data: {json.dumps(chunk)}\n\n"


# ---------------------------------------------------------------------------
# Luma interaction
# ---------------------------------------------------------------------------

async def luma_generate(
    prompt: str,
    resolution: str = "",
    aspect_ratio: str = "",
    image_urls: Optional[list[str]] = None,
) -> str:
    """
    Submit an image generation request to Luma, poll until completed,
    then return the signed CDN image URL.
    If image_urls are provided, uploads them first and passes as references.
    Raises RuntimeError on failure.
    """
    output_id = _random_output_id()
    log.info("Generating image – output_id=%s prompt=%r images=%d",
             output_id, prompt[:80], len(image_urls or []))

    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0), follow_redirects=True) as client:
        # ── Step 0: upload reference images (if any) ──
        references: list[str] = []
        if image_urls:
            for img_url in image_urls:
                try:
                    img_data = await _fetch_image_bytes(img_url, client)
                    artifact_id = await luma_upload_image(img_data, client)
                    references.append(artifact_id)
                except Exception as exc:
                    log.error("Failed to upload reference image: %s", exc)
                    # Continue without this reference rather than failing entirely
            if references:
                log.info("Uploaded %d reference image(s): %s", len(references), references)

        # ── Step 1: submit generation ──
        submit_url = f"https://app.lumalabs.ai/api/vespa/realms/{REALM_ID}/actions"
        body = {
            "type": "create_image_nano_banana_pro",
            "fields": {
                "prompt": prompt,
                "references": references,
            },
            "optimistic_output_ids": [output_id],
        }
        # Only include aspect_ratio / resolution if specified
        if aspect_ratio or ASPECT_RATIO:
            body["fields"]["aspect_ratio"] = aspect_ratio or ASPECT_RATIO
        if resolution:
            body["fields"]["resolution"] = resolution
        resp = await client.post(
            submit_url,
            json=body,
            headers=session._common_headers({
                "accept": "application/json, text/plain, */*",
                "content-type": "application/json",
                "x-client-capabilities": "retry,upgrade_plan",
                "x-client-context": f"id={uuid.uuid4()},name=web,locale=zh-CN",
            }),
        )
        session.update_cookie_from_response(resp)
        log.info("Submit status=%s", resp.status_code)
        if resp.status_code >= 400:
            raise RuntimeError(f"Luma submit failed: {resp.status_code} {resp.text[:300]}")

        submit_data = resp.json()
        action_id = submit_data.get("action", {}).get("id", "")
        artifacts = submit_data.get("output_artifacts", {})
        image_ids = artifacts.get("image", [])
        if image_ids:
            output_id = image_ids[0]
        log.info("action_id=%s output_id=%s", action_id, output_id)

        # ── Step 2: poll action status until completed ──
        actions_url = f"https://app.lumalabs.ai/api/vespa/realms/{REALM_ID}/actions"
        completed = False

        for i in range(MAX_POLLS):
            await asyncio.sleep(POLL_INTERVAL)
            poll_resp = await client.get(
                actions_url,
                headers=session._common_headers({
                    "accept": "application/json, text/plain, */*",
                }),
            )
            session.update_cookie_from_response(poll_resp)

            if poll_resp.status_code != 200:
                log.warning("Poll %d/%d status=%s", i + 1, MAX_POLLS, poll_resp.status_code)
                continue

            actions = poll_resp.json()
            for action in actions:
                if action.get("id") == action_id:
                    state = action.get("state", "")
                    log.info("Poll %d/%d action=%s state=%s", i + 1, MAX_POLLS, action_id, state)
                    if state == "completed":
                        completed = True
                        outputs = action.get("outputs", {})
                        out_images = outputs.get("image", [])
                        if out_images:
                            output_id = out_images[0]
                        break
                    elif state in ("failed", "cancelled"):
                        raise RuntimeError(f"Action {action_id} {state}")
                    break
            else:
                log.warning("Poll %d/%d action %s not found", i + 1, MAX_POLLS, action_id)

            if completed:
                break

        if not completed:
            raise RuntimeError(
                f"Image not ready after {MAX_POLLS * POLL_INTERVAL}s. action_id={action_id}"
            )

        # ── Step 3: get artifact details ──
        artifact_url = f"https://app.lumalabs.ai/api/vespa/realms/{REALM_ID}/artifacts/{output_id}"
        art_resp = await client.get(
            artifact_url,
            headers=session._common_headers({"accept": "application/json"}),
        )
        session.update_cookie_from_response(art_resp)

        if art_resp.status_code != 200:
            raise RuntimeError(f"Failed to get artifact: {art_resp.status_code}")

        artifact = art_resp.json()
        object_ref = artifact.get("object_ref", "")
        if not object_ref:
            raise RuntimeError(f"No object_ref in artifact {output_id}")

        log.info("object_ref=%s", object_ref)

        # ── Step 4: fetch CDN signing params ──
        await session.fetch_signature(client)

        # ── Step 5: build signed CDN URL ──
        image_url = session.build_signed_cdn_url(object_ref)
        log.info("CDN URL built: %s", image_url[:120])

        return image_url


async def luma_generate_with_heartbeat(
    prompt: str, resolution: str, aspect_ratio: str,
    completion_id: str, model: str,
    image_urls: Optional[list[str]] = None,
):
    """
    Generator that yields SSE heartbeat chunks every HEARTBEAT_INTERVAL seconds
    while the image is being generated, then yields the final content and [DONE].
    """
    # Start generation as a background task
    gen_task = asyncio.create_task(
        luma_generate(prompt, resolution, aspect_ratio, image_urls=image_urls)
    )

    # Send initial role chunk
    yield _sse_chunk(completion_id, model)

    # Send heartbeats while waiting
    while not gen_task.done():
        try:
            await asyncio.wait_for(asyncio.shield(gen_task), timeout=HEARTBEAT_INTERVAL)
        except asyncio.TimeoutError:
            # Task not done yet — send heartbeat (empty content)
            yield _sse_chunk(completion_id, model, content="")
            log.info("Heartbeat sent for %s", completion_id)
        except Exception:
            # Task raised an error — break and handle below
            break

    # Task is done — get result or handle exception
    try:
        image_url = gen_task.result()
    except Exception as exc:
        # Send error as content
        error_chunk = _sse_chunk(completion_id, model, content=f"Error: {exc}")
        yield error_chunk
        yield _sse_chunk(completion_id, model, finish_reason="stop")
        yield "data: [DONE]\n\n"
        return

    # Send the image URL as content
    yield _sse_chunk(completion_id, model, content=f"![image]({image_url})")

    # Send finish
    yield _sse_chunk(completion_id, model, finish_reason="stop")
    yield "data: [DONE]\n\n"


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(title="luma2api", version="1.3.0")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "session_valid": bool(session.wos_session),
        "signature_cached": session.is_signature_valid(),
    }


@app.get("/v1/models")
async def list_models():
    """OpenAI-compatible models listing endpoint."""
    return {
        "object": "list",
        "data": [
            {
                "id": model_id,
                "object": "model",
                "created": 1700000000,
                "owned_by": "lumalabs",
            }
            for model_id in MODELS
        ],
    }


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """
    OpenAI-compatible chat completions endpoint.
    Supports both non-streaming and streaming (stream=true) modes.
    Supports image references via OpenAI multimodal content format (image_url).
    In streaming mode, sends SSE heartbeats every 10s to prevent client timeout.
    """
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={
            "error": {"message": "Invalid JSON body", "type": "invalid_request_error"}
        })

    messages = payload.get("messages", [])
    prompt, image_urls = _extract_messages(messages)

    if not prompt.strip():
        return JSONResponse(status_code=400, content={
            "error": {"message": "No user message found or prompt is empty", "type": "invalid_request_error"}
        })

    if image_urls:
        log.info("Found %d image(s) in request", len(image_urls))

    model = payload.get("model", MODEL_BASE)
    stream = payload.get("stream", False)
    completion_id = f"chatcmpl-{uuid.uuid4().hex[:24]}"

    # Resolve resolution and aspect_ratio from model name
    model_config = MODELS.get(model, {"resolution": "", "aspect_ratio": ""})
    resolution = model_config["resolution"]
    aspect_ratio = model_config["aspect_ratio"]
    if model not in MODELS:
        model = MODEL_BASE  # fallback

    # ── Streaming mode ──
    if stream:
        log.info("Streaming request: %s model=%s res=%s ar=%s images=%d prompt=%r",
                 completion_id, model, resolution or "default",
                 aspect_ratio or "default", len(image_urls), prompt[:60])
        return StreamingResponse(
            luma_generate_with_heartbeat(
                prompt.strip(), resolution, aspect_ratio,
                completion_id, model, image_urls=image_urls or None,
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    # ── Non-streaming mode ──
    try:
        image_url = await luma_generate(
            prompt.strip(), resolution, aspect_ratio, image_urls=image_urls or None,
        )
    except RuntimeError as exc:
        log.error("Generation failed: %s", exc)
        return JSONResponse(status_code=500, content={
            "error": {"message": str(exc), "type": "server_error"}
        })
    except Exception as exc:
        log.exception("Unexpected error during generation")
        return JSONResponse(status_code=500, content={
            "error": {"message": f"Internal error: {exc}", "type": "server_error"}
        })

    created = int(time.time())

    result = {
        "id": completion_id,
        "object": "chat.completion",
        "created": created,
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": f"![image]({image_url})",
                },
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": len(prompt),
            "completion_tokens": len(image_url),
            "total_tokens": len(prompt) + len(image_url),
        },
    }
    return JSONResponse(content=result)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    log.info("Starting luma2api on %s:%s", HOST, PORT)
    log.info("Realm: %s", REALM_ID)
    log.info("Models: %s", ", ".join(MODELS.keys()))
    log.info("Cookie auto-refresh: enabled")
    log.info("CDN signature: dynamic")
    log.info("Streaming heartbeat: every %ds", HEARTBEAT_INTERVAL)
    uvicorn.run("app:app", host=HOST, port=PORT, log_level="info")
