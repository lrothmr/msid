# Luma2API

将 [Luma AI](https://lumalabs.ai) 图片生成功能封装为 OpenAI 兼容的 Chat Completions API。

## 功能

- ✅ OpenAI 兼容的 `/v1/chat/completions` 接口
- ✅ `/v1/models` 模型列表接口
- ✅ 流式（SSE）和非流式响应
- ✅ Cookie 自动刷新（`wos-session` 每次请求自动续期）
- ✅ CDN 签名自动获取（无需手动配置）
- ✅ 多分辨率模型支持
- ✅ **图生图（Image Reference）**：支持 OpenAI 多模态格式传入参考图片

## 可用模型

共 28 个模型，由 4 种分辨率 × 7 种宽高比组合生成。

**命名规则：** `nano-banana-pro[-分辨率][-宽高比]`

| 分辨率 \ 宽高比 | 默认 | 16x9 | 1x1 | 9x16 | 4x3 | 3x4 | 21x9 |
|---|---|---|---|---|---|---|---|
| **默认** | `nano-banana-pro` | `-16x9` | `-1x1` | `-9x16` | `-4x3` | `-3x4` | `-21x9` |
| **1K** | `-1k` | `-1k-16x9` | `-1k-1x1` | `-1k-9x16` | `-1k-4x3` | `-1k-3x4` | `-1k-21x9` |
| **2K** | `-2k` | `-2k-16x9` | `-2k-1x1` | `-2k-9x16` | `-2k-4x3` | `-2k-3x4` | `-2k-21x9` |
| **4K** | `-4k` | `-4k-16x9` | `-4k-1x1` | `-4k-9x16` | `-4k-4x3` | `-4k-3x4` | `-4k-21x9` |

> 表中所有名称前缀均为 `nano-banana-pro`，如 `-2k-16x9` 完整写法为 `nano-banana-pro-2k-16x9`。

## 快速开始

### 1. 获取 Cookie

1. 浏览器打开 [app.lumalabs.ai](https://app.lumalabs.ai) 并登录
2. 按 `F12` → `Application` → `Cookies` → `app.lumalabs.ai`
3. 复制 `wos-session` 的值
4. 从地址栏 `https://app.lumalabs.ai/board/{REALM_ID}` 获取 Realm ID

### 2. 配置

```bash
cp .env.example .env
```

编辑 `.env`，填入 `LUMA_REALM_ID` 和 `LUMA_WOS_SESSION`。

### 3. 启动

**Docker（推荐）：**

```bash
docker-compose up -d
```

**Windows 本地运行（无 Docker）：**

```powershell
# 安装依赖
pip install -r requirements.txt

# 启动服务
python app.py
```

服务将在 `http://localhost:8188` 上运行。

### 4. 使用

```bash
# 查看模型
curl http://localhost:8188/v1/models

# 生成图片（非流式）
curl http://localhost:8188/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "nano-banana-pro",
    "messages": [{"role": "user", "content": "A cute cat sitting on a rainbow"}]
  }'

# 生成图片（流式，推荐）
curl -N http://localhost:8188/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "nano-banana-pro-2k",
    "stream": true,
    "messages": [{"role": "user", "content": "A cute cat sitting on a rainbow"}]
  }'

# 图生图（传入参考图片 URL）
curl http://localhost:8188/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "nano-banana-pro-2k",
    "messages": [{
      "role": "user",
      "content": [
        {"type": "text", "text": "Transform this into a watercolor painting"},
        {"type": "image_url", "image_url": {"url": "https://example.com/photo.jpg"}}
      ]
    }]
  }'

# 图生图（传入 base64 图片）
curl http://localhost:8188/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "nano-banana-pro-2k",
    "messages": [{
      "role": "user",
      "content": [
        {"type": "text", "text": "Make this image more colorful"},
        {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,/9j/4AAQ..."}}
      ]
    }]
  }'
```

## 配置项

| 环境变量 | 必填 | 默认值 | 说明 |
|---|---|---|---|
| `LUMA_REALM_ID` | ✅ | - | Luma Realm ID |
| `LUMA_WOS_SESSION` | ✅ | - | 初始 wos-session cookie |
| `LUMA_ASPECT_RATIO` | ❌ | 空 | 宽高比（`16:9`, `1:1`, `9:16` 等） |
| `LUMA_POLL_INTERVAL` | ❌ | `3` | 轮询间隔（秒） |
| `LUMA_MAX_POLLS` | ❌ | `60` | 最大轮询次数 |
| `PORT` | ❌ | `8188` | 服务端口 |
| `HOST` | ❌ | `0.0.0.0` | 监听地址 |

## API 端点

### `GET /v1/models`

返回可用模型列表。

### `POST /v1/chat/completions`

OpenAI Chat Completions 兼容接口。从最后一条 user 消息提取 prompt 生成图片。

支持两种消息格式：

**纯文本（文生图）：**

```json
{
  "model": "nano-banana-pro",
  "stream": true,
  "messages": [
    {"role": "user", "content": "你的图片描述"}
  ]
}
```

**多模态（图生图）：**

```json
{
  "model": "nano-banana-pro-2k",
  "messages": [{
    "role": "user",
    "content": [
      {"type": "text", "text": "将这张图片转换为水彩画风格"},
      {"type": "image_url", "image_url": {"url": "https://example.com/photo.jpg"}}
    ]
  }]
}
```

> 图片支持 URL 和 base64 data URI 两种格式（`data:image/jpeg;base64,...`）。
> 支持 JPEG、PNG、GIF、WebP、BMP 格式。可同时传入多张参考图片。

**响应（非流式）：**

```json
{
  "id": "chatcmpl-xxx",
  "object": "chat.completion",
  "model": "nano-banana-pro",
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "![image](https://cdn.prod01.labs.lumalabs.ai/...)"
    },
    "finish_reason": "stop"
  }]
}
```

**响应（流式）：** SSE 格式，生成期间每 10 秒发送心跳包防止超时。

### `GET /health`

健康检查。

## 查看日志

```bash
docker-compose logs -f
```

## 许可

MIT
